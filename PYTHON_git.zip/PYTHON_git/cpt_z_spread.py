# %% COMPUTE Z-SPREAD USING SOFR CURVE
# ==========================================================
# Author: Amin Tarbouch
# ==========================================================

import pandas as pd
import numpy as np
from pathlib import Path
from scipy.optimize import brentq
from path_config import FEATURE_ENGINEERED, SOFR_CURVE, Z_SPREADS

class ZSpreadCalculator:
    """
    Computes Z-spreads for bonds using a risk-free zero curve (e.g., SOFR).
    """

    def __init__(self, bonds_path: Path, curve_path: Path):
        """
        Parameters
        ----------
        bonds_path : Path
            Path to the Excel file containing bond data (with prices, coupons, maturities, etc.)
        curve_path : Path
            Path to the Excel file containing the SOFR zero curve time series.
        """
        self.bonds_path = bonds_path
        self.curve_path = curve_path
        self.df_bonds = None
        self.df_curve = None

    # --------------------------------------------------
    def load_data(self):
        """Load bond dataset and SOFR curve."""
        self.df_bonds = pd.read_excel(self.bonds_path)
        self.df_curve = pd.read_excel(self.curve_path)

        # Clean columns
        self.df_bonds.columns = self.df_bonds.columns.str.upper().str.strip()
        self.df_curve.columns = self.df_curve.columns.str.strip()

        # Convert dates
        for col in ["DATE", "MATURITY"]:
            if col in self.df_bonds.columns:
                self.df_bonds[col] = pd.to_datetime(self.df_bonds[col], errors="coerce")

        if "Date" in self.df_curve.columns:
            self.df_curve["Date"] = pd.to_datetime(self.df_curve["Date"], errors="coerce")

        print(f"✅ Loaded bonds: {self.df_bonds.shape}, curve: {self.df_curve.shape}")

    # --------------------------------------------------
    def _interpolate_zero_rate(self, valuation_date, maturity_years):
        """
        Interpolates the zero rate from the SOFR curve for a given valuation date and maturity.
        """
        df_curve_day = self.df_curve[self.df_curve["Date"] == valuation_date]
        if df_curve_day.empty:
            return np.nan

        x = df_curve_day["Maturity (Years)"].values
        y = df_curve_day["Zero Rate (%)"].values / 100  # convert to decimal

        if len(x) < 2:
            return np.nan

        return np.interp(maturity_years, x, y)

    def _price_from_zspread(self, row, z_spread):
        """
        Computes the theoretical price as % of par given a z-spread.
        Works entirely in % of par — PAR_VAL not needed.
        """
        c = row["COUPON"] / 100          # coupon rate per period (% of par)
        T = (row["MATURITY"] - row["DATE"]).days / 365.25

        if T <= 0:
            return np.nan

        # Annual cashflows
        times      = np.arange(1, int(np.floor(T)) + 1, dtype=float)
        times      = np.append(times, T)
        cashflows  = np.full_like(times, c, dtype=float)
        cashflows[-1] += 1.0             # redemption at 100% of par = 1.0

        # Interpolate zero rates for each cashflow
        zero_rates = [self._interpolate_zero_rate(row["DATE"], t) for t in times]
        if any(pd.isna(zero_rates)):
            return np.nan

        # Discount with z-spread
        discount_factors = [(1 + r + z_spread) ** (-t) for r, t in zip(zero_rates, times)]
        return np.sum(cashflows * discount_factors)   # result is % of par (e.g. 0.98 = 98%)


    def _solve_zspread(self, row):
        """
        Solves for the z-spread matching the market dirty price (% of par).
        PAR_VAL not needed — everything normalized to % of par.
        """
        market_price_pct = row["DIRTY_PRICE"] / 100   # e.g. 98.5 -> 0.985

        def objective(z):
            return self._price_from_zspread(row, z) - market_price_pct

        try:
            z = brentq(objective, -0.50, 0.50)   # ±50% range, safer for EM bonds
            return z * 10000                      # convert to bps
        except Exception:
            return np.nan

    # --------------------------------------------------
    def compute_zspreads(self):
        """Compute Z-spreads for all bonds. PAR_VAL not required."""
        df = self.df_bonds.copy()

        required_cols = ["DATE", "MATURITY", "DIRTY_PRICE", "COUPON"]  # PAR_VAL removed
        for col in required_cols:
            if col not in df.columns:
                raise ValueError(f"❌ Missing required column: {col}")

        print("⚙️ Computing Z-spreads...")
        df["Z_SPREAD_BPS"] = df.apply(self._solve_zspread, axis=1)
        print("✅ Z-spread computation complete.")
        return df

    # --------------------------------------------------
    def export_results(self, df_out: pd.DataFrame, output_path: Path):
        """Export results to Excel."""
        df_out.to_excel(output_path, index=False)
        print(f"📦 Z-spread results exported to: {output_path}")


# ==========================================================
# MAIN PIPELINE
# ==========================================================
if __name__ == "__main__":

    zcalc = ZSpreadCalculator(FEATURE_ENGINEERED, SOFR_CURVE)
    zcalc.load_data()
    df_z = zcalc.compute_zspreads()
    zcalc.export_results(df_z, Z_SPREADS)

# %%
