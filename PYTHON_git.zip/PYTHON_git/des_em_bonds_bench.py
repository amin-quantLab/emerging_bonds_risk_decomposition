# %% DESCRIBE DATASET

import re
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from pathlib import Path
from plotly.subplots import make_subplots
from path_config import BBG_BONDS, DEFAULT_SHEET

class BondDatasetAnalyzer:
    def __init__(
        self,
        file_path: str,
        sheet_name: str = None,
        issue_date_cap: str = None,
        latam_only: bool = False,
        latam_subregions="all",
        exclude_government: bool = False
    ):
        """
        Initialize the analyzer.

        Parameters
        ----------
        file_path : str
            Path to the Excel dataset.
        sheet_name : str, optional
            Excel sheet name.
        issue_date_cap : str, optional
            Keep only bonds issued on or before this date, format 'YYYY-MM-DD'.
        latam_only : bool, optional
            If True, keep only Latin America / Caribbean countries.
        latam_subregions : "all" or list[str], optional
            Filter within LatAm using the 3 subregions:
            - South America
            - Mexico / Central America
            - Caribbean
        exclude_government : bool, optional
            If True, remove rows where INDUSTRY_SECTOR == "Government".
        """
        self.file_path = file_path
        self.sheet_name = sheet_name
        self.issue_date_cap = pd.to_datetime(issue_date_cap) if issue_date_cap else None
        self.latam_only = latam_only
        self.exclude_government = exclude_government
        self.df = None

        self.issue_col = "ISSUE_DT"
        self.maturity_col = "MATURITY"
        self.sector_col = "INDUSTRY_SECTOR"
        self.country_col = "COUNTRY_FULL_NAME"
        self.latam_country_col = "LATIN_AMERICA_COUNTRY"
        self.latam_subregion_col = "LATAM_SUBREGION"

        self.valid_latam_subregions = [
            "South America",
            "Mexico / Central America",
            "Caribbean"
        ]
        self.latam_subregions = self._normalize_latam_subregions_input(latam_subregions)

        self.latam_country_info = {
            # South America
            "ARGENTINA": ("ARGENTINA", "South America"),
            "BOLIVIA": ("BOLIVIA", "South America"),
            "BRAZIL": ("BRAZIL", "South America"),
            "CHILE": ("CHILE", "South America"),
            "COLOMBIA": ("COLOMBIA", "South America"),
            "ECUADOR": ("ECUADOR", "South America"),
            "GUYANA": ("GUYANA", "South America"),
            "PARAGUAY": ("PARAGUAY", "South America"),
            "PERU": ("PERU", "South America"),
            "SURINAME": ("SURINAME", "South America"),
            "URUGUAY": ("URUGUAY", "South America"),
            "VENEZUELA": ("VENEZUELA", "South America"),

            # Mexico / Central America
            "MEXICO": ("MEXICO", "Mexico / Central America"),
            "BELIZE": ("BELIZE", "Mexico / Central America"),
            "COSTA RICA": ("COSTA RICA", "Mexico / Central America"),
            "EL SALVADOR": ("EL SALVADOR", "Mexico / Central America"),
            "GUATEMALA": ("GUATEMALA", "Mexico / Central America"),
            "HONDURAS": ("HONDURAS", "Mexico / Central America"),
            "NICARAGUA": ("NICARAGUA", "Mexico / Central America"),
            "PANAMA": ("PANAMA", "Mexico / Central America"),

            # Caribbean
            "BAHAMAS": ("BAHAMAS", "Caribbean"),
            "BERMUDA": ("BERMUDA", "Caribbean"),
            "BRITISH VIRGIN": ("BRITISH VIRGIN ISLANDS", "Caribbean"),
            "BRITISH VIRGIN ISLANDS": ("BRITISH VIRGIN ISLANDS", "Caribbean"),
            "CAYMAN ISLANDS": ("CAYMAN ISLANDS", "Caribbean"),
            "CUBA": ("CUBA", "Caribbean"),
            "CURACAO": ("CURACAO", "Caribbean"),
            "DOMINICAN REPUBLIC": ("DOMINICAN REPUBLIC", "Caribbean"),
            "DOMINICAN REPUB": ("DOMINICAN REPUBLIC", "Caribbean"),
            "DOMINICAN REPB": ("DOMINICAN REPUBLIC", "Caribbean"),
            "HAITI": ("HAITI", "Caribbean"),
            "JAMAICA": ("JAMAICA", "Caribbean"),
            "PUERTO RICO": ("PUERTO RICO", "Caribbean"),
            "TRINIDAD AND TOBAGO": ("TRINIDAD AND TOBAGO", "Caribbean"),
            "TRINIDAD AND TO": ("TRINIDAD AND TOBAGO", "Caribbean"),
        }

    def _normalize_latam_subregions_input(self, latam_subregions):
        if latam_subregions is None:
            return "all"

        if isinstance(latam_subregions, str):
            if latam_subregions.strip().lower() == "all":
                return "all"
            latam_subregions = [latam_subregions]

        alias_map = {
            "SOUTH AMERICA": "South America",
            "MEXICO / CENTRAL AMERICA": "Mexico / Central America",
            "MEXICO/CENTRAL AMERICA": "Mexico / Central America",
            "CENTRAL AMERICA": "Mexico / Central America",
            "CARIBBEAN": "Caribbean",
        }

        normalized = []
        for region in latam_subregions:
            key = str(region).upper().strip()
            if key not in alias_map:
                raise ValueError(
                    f"Invalid latam_subregion '{region}'. Valid values are: 'all' or {self.valid_latam_subregions}"
                )
            normalized.append(alias_map[key])

        return list(dict.fromkeys(normalized))

    def _latam_scope_active(self):
        return self.latam_only or self.latam_subregions != "all"

    def _latam_scope_text(self):
        if self.latam_subregions == "all":
            return "all"
        return ", ".join(self.latam_subregions)

    def _analysis_country_col(self):
        return self.latam_country_col if self._latam_scope_active() else self.country_col

    def _analysis_country_label(self):
        return "Latin America / Caribbean Country" if self._latam_scope_active() else "Country"

    def _title_suffix(self):
        return " (ex-Government)" if self.exclude_government else ""

    def _filter_government_if_needed(self):
        if not self.exclude_government:
            return

        before = len(self.df)
        sector_series = (
            self.df[self.sector_col]
            .astype("string")
            .fillna("")
            .str.strip()
            .str.upper()
        )
        self.df = self.df[sector_series != "GOVERNMENT"].copy()
        print(f"Government sector excluded: {before} -> {len(self.df)} bonds")

    def _color_list(self, n):
        palette = px.colors.qualitative.Plotly
        return [palette[i % len(palette)] for i in range(n)]

    def load_and_clean(self):
        """Load, clean, classify, and inspect the dataset."""
        sheet = self.sheet_name if self.sheet_name is not None else 0
        self.df = pd.read_excel(self.file_path, sheet_name=sheet)

        self.df = self.df.replace(r"^\s*$", pd.NA, regex=True)
        self.df = self.df.replace(
            ["nan", "NaN", "None", "NONE", "NaT", "NULL", "N/A", "#N/A"],
            pd.NA
        )

        for col in self.df.select_dtypes(include=["object"]).columns:
            self.df[col] = self.df[col].astype("string").str.strip()

        for col in [self.issue_col, self.maturity_col]:
            if col in self.df.columns:
                self.df[col] = pd.to_datetime(self.df[col], errors="coerce", dayfirst=True)

        for col in ["MV", "Par Val", "PRICE", "YTW", "OAD", "WEIGHT", "CPN", "COUPON"]:
            if col in self.df.columns:
                self.df[col] = (
                    self.df[col]
                    .astype(str)
                    .str.replace(",", "", regex=False)
                    .str.replace(" ", "", regex=False)
                    .str.replace("\u00a0", "", regex=False)
                    .str.replace("%", "", regex=False)
                )
                self.df[col] = pd.to_numeric(self.df[col], errors="coerce")

        if self.issue_date_cap is not None and self.issue_col in self.df.columns:
            self.df = self.df[self.df[self.issue_col] <= self.issue_date_cap].copy()

        if self.issue_col in self.df.columns:
            self.df["ISSUE_YEAR"] = self.df[self.issue_col].dt.year

        if self.maturity_col in self.df.columns:
            self.df["MATURITY_YEAR"] = self.df[self.maturity_col].dt.year

        self._require_columns([self.sector_col, self.country_col])

        print(f"\nUsing country column: {self.country_col}")
        print(f"Using maturity column: {self.maturity_col}")

        if "Par Val" in self.df.columns:
            self.df["PAR_VAL_USD"] = self.df["Par Val"]

        self._filter_government_if_needed()

        self.df[self.latam_country_col] = self.df[self.country_col].apply(self._latin_america_display_name)
        self.df[self.latam_subregion_col] = self.df[self.country_col].apply(self._latam_subregion_from_country)

        if self._latam_scope_active():
            before = len(self.df)
            self.df = self.df.dropna(subset=[self.latam_country_col]).copy()
            print(f"LATAM scope applied: {before} -> {len(self.df)} bonds")

        if self.latam_subregions != "all":
            before = len(self.df)
            self.df = self.df[self.df[self.latam_subregion_col].isin(self.latam_subregions)].copy()
            print(f"LATAM subregion filter applied ({self._latam_scope_text()}): {before} -> {len(self.df)} bonds")

        if self.df.empty:
            raise ValueError("No rows left after applying the selected filters.")

        print("\nColumn format check:")
        for col in self.df.columns:
            dtype = self.df[col].dtype
            sample_values = self.df[col].dropna().unique()[:3]
            print(f"• {col:<30} | dtype: {str(dtype):<12} | sample: {sample_values}")

        print(f"\nDataset loaded: {len(self.df)} bonds after filtering.")
        return self.df

    def _normalize_country_name(self, value):
        if pd.isna(value):
            return ""

        text = str(value).upper().strip()
        text = re.sub(r"\([^)]*\)", "", text)
        text = text.replace("&", "AND").replace(".", " ").replace(",", " ")
        text = re.sub(r"\s+", " ", text).strip()
        return text

    def _match_latam_country_info(self, value):
        normalized = self._normalize_country_name(value)

        if not normalized:
            return None

        if normalized in self.latam_country_info:
            return self.latam_country_info[normalized]

        if normalized.startswith("DOMINICAN REP"):
            return ("DOMINICAN REPUBLIC", "Caribbean")
        if normalized.startswith("TRINIDAD AND TO"):
            return ("TRINIDAD AND TOBAGO", "Caribbean")
        if normalized.startswith("BRITISH VIRGIN"):
            return ("BRITISH VIRGIN ISLANDS", "Caribbean")
        if normalized.startswith("GUATEMALA"):
            return ("GUATEMALA", "Mexico / Central America")
        if normalized.startswith("HONDURAS"):
            return ("HONDURAS", "Mexico / Central America")

        return None

    def _latin_america_display_name(self, value):
        match = self._match_latam_country_info(value)
        return match[0] if match else pd.NA

    def _latam_subregion_from_country(self, value):
        match = self._match_latam_country_info(value)
        return match[1] if match else pd.NA

    def _require_columns(self, required_cols):
        missing_cols = [col for col in required_cols if col not in self.df.columns]
        if missing_cols:
            raise KeyError(f"Missing required columns: {missing_cols}")

    def _safe_category(self, df, col, unknown_label="Unknown"):
        return (
            df[col]
            .fillna(unknown_label)
            .astype(str)
            .str.strip()
            .replace({
                "": unknown_label,
                "nan": unknown_label,
                "None": unknown_label,
                "NaT": unknown_label
            })
        )

    def _get_country_par_value_data(self):
        if "PAR_VAL_USD" not in self.df.columns:
            return None, None, None

        country_col = self._analysis_country_col()
        country_label = self._analysis_country_label()

        self._require_columns([country_col])

        plot_df = self.df.dropna(subset=[country_col]).copy()
        if plot_df.empty:
            return None, country_col, country_label

        plot_df[country_col] = self._safe_category(plot_df, country_col)

        data = (
            plot_df
            .groupby(country_col, dropna=False)
            .agg(
                Bonds_Count=(country_col, "size"),
                Total_Par_Value_USD=("PAR_VAL_USD", "sum")
            )
            .reset_index()
            .sort_values("Total_Par_Value_USD", ascending=False)
        )

        return data, country_col, country_label

    def _get_sector_par_value_data(self):
        if "PAR_VAL_USD" not in self.df.columns:
            return None

        plot_df = self.df.copy()
        plot_df[self.sector_col] = self._safe_category(plot_df, self.sector_col)

        agg_dict = {
            "Bonds_Count": (self.sector_col, "size"),
            "Total_Par_Value_USD": ("PAR_VAL_USD", "sum")
        }

        if "YTW" in plot_df.columns:
            agg_dict["Average_YTW"] = ("YTW", "mean")
        if "OAD" in plot_df.columns:
            agg_dict["Average_OAD"] = ("OAD", "mean")

        data = (
            plot_df
            .groupby(self.sector_col, dropna=False)
            .agg(**agg_dict)
            .reset_index()
            .sort_values("Total_Par_Value_USD", ascending=False)
        )

        return data

    def plot_issue_year_repartition(self, split_by_sector: bool = True, barmode: str = "stack"):
        """
        Plot repartition of bonds per issue year.

        Parameters
        ----------
        split_by_sector : bool
            If True, split bars by sector.
        barmode : str
            "stack" or "group".
        """
        if "ISSUE_YEAR" not in self.df.columns:
            print("ISSUE_YEAR is missing. Check ISSUE_DT column.")
            return

        if split_by_sector and self.sector_col in self.df.columns:
            plot_df = self.df.dropna(subset=["ISSUE_YEAR"]).copy()
            plot_df[self.sector_col] = self._safe_category(plot_df, self.sector_col)

            data = (
                plot_df
                .groupby(["ISSUE_YEAR", self.sector_col], dropna=False)
                .size()
                .reset_index(name="Count")
                .sort_values(["ISSUE_YEAR", self.sector_col])
            )

            fig = px.bar(
                data,
                x="ISSUE_YEAR",
                y="Count",
                color=self.sector_col,
                title=f"Repartition of Bonds per Issue Year by Sector{self._title_suffix()}",
                template="plotly_white",
                barmode=barmode
            )

            fig.update_layout(
                xaxis_title="Issue Year",
                yaxis_title="Number of Bonds",
                legend_title="Sector"
            )
            fig.show()

        else:
            data = (
                self.df["ISSUE_YEAR"]
                .dropna()
                .value_counts()
                .sort_index()
                .reset_index()
            )
            data.columns = ["Issue Year", "Count"]

            fig = px.bar(
                data,
                x="Issue Year",
                y="Count",
                title=f"Repartition of Bonds per Issue Year{self._title_suffix()}",
                text="Count",
                template="plotly_white"
            )
            fig.update_traces(textposition="outside")
            fig.update_layout(
                xaxis_title="Issue Year",
                yaxis_title="Number of Bonds"
            )
            fig.show()

    def plot_maturity_year_repartition(self, split_by_sector: bool = True, barmode: str = "stack"):
        """
        Plot repartition of bonds per maturity year.

        Parameters
        ----------
        split_by_sector : bool
            If True, split bars by sector.
        barmode : str
            "stack" or "group".
        """
        if "MATURITY_YEAR" not in self.df.columns:
            print("MATURITY_YEAR is missing. Check MATURITY column.")
            return

        if split_by_sector and self.sector_col in self.df.columns:
            plot_df = self.df.dropna(subset=["MATURITY_YEAR"]).copy()
            plot_df[self.sector_col] = self._safe_category(plot_df, self.sector_col)

            data = (
                plot_df
                .groupby(["MATURITY_YEAR", self.sector_col], dropna=False)
                .size()
                .reset_index(name="Count")
                .sort_values(["MATURITY_YEAR", self.sector_col])
            )

            fig = px.bar(
                data,
                x="MATURITY_YEAR",
                y="Count",
                color=self.sector_col,
                title=f"Repartition of Bonds per Maturity Year by Sector{self._title_suffix()}",
                template="plotly_white",
                barmode=barmode
            )

            fig.update_layout(
                xaxis_title="Maturity Year",
                yaxis_title="Number of Bonds",
                legend_title="Sector"
            )
            fig.show()

        else:
            data = (
                self.df["MATURITY_YEAR"]
                .dropna()
                .value_counts()
                .sort_index()
                .reset_index()
            )
            data.columns = ["Maturity Year", "Count"]

            fig = px.bar(
                data,
                x="Maturity Year",
                y="Count",
                title=f"Repartition of Bonds per Maturity Year{self._title_suffix()}",
                text="Count",
                template="plotly_white"
            )
            fig.update_traces(textposition="outside")
            fig.update_layout(
                xaxis_title="Maturity Year",
                yaxis_title="Number of Bonds"
            )
            fig.show()

    def plot_country_repartition(self):
        country_col = self._analysis_country_col()
        country_label = self._analysis_country_label()

        self._require_columns([country_col])

        plot_df = self.df.copy()
        plot_df[country_col] = self._safe_category(plot_df, country_col)

        agg_dict = {"Bonds_Count": (country_col, "size")}
        if "PAR_VAL_USD" in plot_df.columns:
            agg_dict["Total_Par_Value_USD"] = ("PAR_VAL_USD", "sum")

        data = (
            plot_df
            .groupby(country_col, dropna=False)
            .agg(**agg_dict)
            .reset_index()
            .sort_values("Bonds_Count", ascending=False)
        )

        hover_data = {"Bonds_Count": True}
        if "Total_Par_Value_USD" in data.columns:
            hover_data["Total_Par_Value_USD"] = ":,.0f"

        title = (
            "Number of Bonds per Latin America / Caribbean Country"
            if self._latam_scope_active() else
            "Number of Bonds per Country"
        )

        fig = px.bar(
            data,
            x=country_col,
            y="Bonds_Count",
            color=country_col,
            text="Bonds_Count",
            title=f"{title}{self._title_suffix()}",
            hover_data=hover_data,
            template="plotly_white"
        )
        fig.update_traces(textposition="outside")
        fig.update_xaxes(categoryorder="array", categoryarray=data[country_col])
        fig.update_layout(
            xaxis_title=country_label,
            yaxis_title="Number of Bonds",
            xaxis_tickangle=-45,
            showlegend=False
        )
        fig.show()

    def plot_par_value_dashboard(self):
        """Plot all PAR value charts in one figure using subplots."""
        if "PAR_VAL_USD" not in self.df.columns:
            print("PAR_VAL is missing. Cannot build PAR value dashboard.")
            return

        country_data, country_col, country_label = self._get_country_par_value_data()
        sector_data = self._get_sector_par_value_data()

        if sector_data is None or sector_data.empty:
            print("No sector PAR value data available.")
            return

        fig = make_subplots(
            rows=2,
            cols=2,
            specs=[
                [{"type": "xy"}, {"type": "xy"}],
                [{"type": "domain", "colspan": 2}, None]
            ],
            subplot_titles=(
                f"Total PAR Value by {country_label}" if country_data is not None else "Total PAR Value by Country",
                "Total PAR Value by Sector",
                "Sector Exposure Treemap by PAR Value"
            ),
            horizontal_spacing=0.10,
            vertical_spacing=0.14
        )

        if country_data is not None and not country_data.empty:
            fig.add_trace(
                go.Bar(
                    x=country_data[country_col],
                    y=country_data["Total_Par_Value_USD"],
                    text=country_data["Bonds_Count"],
                    customdata=country_data[["Bonds_Count"]].to_numpy(),
                    marker_color=self._color_list(len(country_data)),
                    hovertemplate=(
                        "<b>%{x}</b><br>"
                        "Total PAR Value USD: %{y:,.0f}<br>"
                        "Bonds Count: %{customdata[0]}<extra></extra>"
                    ),
                    textposition="outside"
                ),
                row=1,
                col=1
            )

            fig.update_xaxes(
                categoryorder="array",
                categoryarray=country_data[country_col],
                tickangle=-45,
                row=1,
                col=1
            )
            fig.update_yaxes(title_text="Total PAR Value USD", row=1, col=1)

        sector_custom_cols = ["Bonds_Count"]
        sector_hover = (
            "<b>%{x}</b><br>"
            "Total PAR Value USD: %{y:,.0f}<br>"
            "Bonds Count: %{customdata[0]}"
        )

        if "Average_YTW" in sector_data.columns:
            sector_custom_cols.append("Average_YTW")
            sector_hover += "<br>Average YTW: %{customdata[1]:.2f}"

        if "Average_OAD" in sector_data.columns:
            sector_custom_cols.append("Average_OAD")
            idx = len(sector_custom_cols) - 1
            sector_hover += f"<br>Average OAD: %{{customdata[{idx}]:.2f}}"

        sector_hover += "<extra></extra>"

        fig.add_trace(
            go.Bar(
                x=sector_data[self.sector_col],
                y=sector_data["Total_Par_Value_USD"],
                text=sector_data["Bonds_Count"],
                customdata=sector_data[sector_custom_cols].to_numpy(),
                marker_color=self._color_list(len(sector_data)),
                hovertemplate=sector_hover,
                textposition="outside"
            ),
            row=1,
            col=2
        )

        fig.update_xaxes(
            categoryorder="array",
            categoryarray=sector_data[self.sector_col],
            tickangle=-45,
            row=1,
            col=2
        )
        fig.update_yaxes(title_text="Total PAR Value USD", row=1, col=2)

        treemap_custom_cols = ["Bonds_Count"]
        treemap_hover = (
            "<b>%{label}</b><br>"
            "Total PAR Value USD: %{value:,.0f}<br>"
            "Bonds Count: %{customdata[0]}"
        )

        if "Average_YTW" in sector_data.columns:
            treemap_custom_cols.append("Average_YTW")
            treemap_hover += "<br>Average YTW: %{customdata[1]:.2f}"

        if "Average_OAD" in sector_data.columns:
            treemap_custom_cols.append("Average_OAD")
            idx = len(treemap_custom_cols) - 1
            treemap_hover += f"<br>Average OAD: %{{customdata[{idx}]:.2f}}"

        treemap_hover += "<extra></extra>"

        treemap_kwargs = {}
        if "Average_YTW" in sector_data.columns:
            treemap_kwargs["marker"] = dict(
                colors=sector_data["Average_YTW"],
                colorscale="Viridis",
                colorbar=dict(title="Avg YTW")
            )

        fig.add_trace(
            go.Treemap(
                labels=sector_data[self.sector_col],
                parents=[""] * len(sector_data),
                values=sector_data["Total_Par_Value_USD"],
                text=sector_data["Bonds_Count"],
                customdata=sector_data[treemap_custom_cols].to_numpy(),
                texttemplate="%{label}<br>%{value:,.0f}",
                hovertemplate=treemap_hover,
                **treemap_kwargs
            ),
            row=2,
            col=1
        )

        fig.update_layout(
            title_text=f"PAR Value Dashboard{self._title_suffix()}",
            template="plotly_white",
            height=1000,
            margin=dict(t=100, l=40, r=40, b=40)
        )

        fig.show()

    def plot_sector_repartition(self):
        """
        Plot:
        - number of bonds by sector
        - number of unique issuers by sector

        in one figure with 2 subplots.
        """
        if self.sector_col not in self.df.columns:
            print(f"{self.sector_col} column is missing.")
            return

        plot_df = self.df.copy()
        plot_df[self.sector_col] = self._safe_category(plot_df, self.sector_col)

        # --- Bonds by sector ---
        sector_bonds = (
            plot_df[self.sector_col]
            .value_counts()
            .reset_index()
        )
        sector_bonds.columns = ["Sector", "Bonds_Count"]

        sector_order = sector_bonds["Sector"].tolist()
        colors = self._color_list(len(sector_order))
        color_map = dict(zip(sector_order, colors))

        # If ISSUER is missing, keep the old one-chart behavior
        if "ISSUER" not in plot_df.columns:
            print("ISSUER column is missing. Showing only bonds by sector.")

            fig = px.bar(
                sector_bonds,
                x="Sector",
                y="Bonds_Count",
                color="Sector",
                title=f"Repartition of Bonds by Sector{self._title_suffix()}",
                text="Bonds_Count",
                template="plotly_white"
            )
            fig.update_traces(textposition="outside")
            fig.update_xaxes(categoryorder="array", categoryarray=sector_order)
            fig.update_layout(
                xaxis_title="Sector",
                yaxis_title="Number of Bonds",
                xaxis_tickangle=-45,
                showlegend=False
            )
            fig.show()
            return

        # --- Unique issuers by sector ---
        plot_df["ISSUER"] = self._safe_category(plot_df, "ISSUER")

        sector_issuers = (
            plot_df
            .groupby(self.sector_col, dropna=False)["ISSUER"]
            .nunique()
            .reset_index(name="Unique_Issuers")
        )

        sector_issuers.columns = ["Sector", "Unique_Issuers"]
        sector_issuers["Sector"] = pd.Categorical(
            sector_issuers["Sector"],
            categories=sector_order,
            ordered=True
        )
        sector_issuers = sector_issuers.sort_values("Sector")

        # --- Subplots ---
        fig = make_subplots(
            rows=1,
            cols=2,
            subplot_titles=(
                f"Number of Bonds by Sector{self._title_suffix()}",
                f"Number of Unique Issuers by Sector{self._title_suffix()}"
            ),
            horizontal_spacing=0.10
        )

        # Left: bonds
        fig.add_trace(
            go.Bar(
                x=sector_bonds["Sector"],
                y=sector_bonds["Bonds_Count"],
                text=sector_bonds["Bonds_Count"],
                marker_color=[color_map[s] for s in sector_bonds["Sector"]],
                textposition="outside",
                hovertemplate=(
                    "<b>%{x}</b><br>"
                    "Number of Bonds: %{y}<extra></extra>"
                ),
                showlegend=False
            ),
            row=1,
            col=1
        )

        # Right: unique issuers
        fig.add_trace(
            go.Bar(
                x=sector_issuers["Sector"],
                y=sector_issuers["Unique_Issuers"],
                text=sector_issuers["Unique_Issuers"],
                marker_color=[color_map[s] for s in sector_issuers["Sector"]],
                textposition="outside",
                hovertemplate=(
                    "<b>%{x}</b><br>"
                    "Number of Unique Issuers: %{y}<extra></extra>"
                ),
                showlegend=False
            ),
            row=1,
            col=2
        )

        fig.update_xaxes(
            categoryorder="array",
            categoryarray=sector_order,
            tickangle=-45,
            row=1,
            col=1
        )
        fig.update_xaxes(
            categoryorder="array",
            categoryarray=sector_order,
            tickangle=-45,
            row=1,
            col=2
        )

        fig.update_yaxes(title_text="Number of Bonds", row=1, col=1)
        fig.update_yaxes(title_text="Number of Unique Issuers", row=1, col=2)

        fig.update_layout(
            title_text=f"Sector Breakdown{self._title_suffix()}",
            template="plotly_white",
            height=650,
            margin=dict(t=100, l=40, r=40, b=40)
        )

        fig.show()

    def plot_yield_duration_by_sector(self):
        required_cols = ["YTW", "OAD", self.sector_col]
        missing_cols = [col for col in required_cols if col not in self.df.columns]
        if missing_cols:
            print(f"Missing columns for YTW/OAD graph: {missing_cols}")
            return

        plot_df = self.df.dropna(subset=["YTW", "OAD", self.sector_col]).copy()
        plot_df[self.sector_col] = self._safe_category(plot_df, self.sector_col)

        if plot_df.empty:
            print("No valid YTW/OAD data available for plotting.")
            return

        hover_cols = [
            col for col in ["ISIN", "NAME", "ISSUER", "CPN", "PRICE", "PAR_VAL_USD", "WEIGHT"]
            if col in plot_df.columns
        ]

        fig = px.scatter(
            plot_df,
            x="OAD",
            y="YTW",
            color=self.sector_col,
            size="PAR_VAL_USD" if "PAR_VAL_USD" in plot_df.columns else None,
            hover_data=hover_cols,
            title=f"Yield-to-Worst vs Option-Adjusted Duration by Sector{self._title_suffix()}",
            template="plotly_white",
            size_max=30
        )
        fig.update_layout(
            xaxis_title="Option-Adjusted Duration (OAD)",
            yaxis_title="Yield-to-Worst (YTW)",
            legend_title="Sector"
        )
        fig.show()

    def plot_unique_issuers_and_issues_by_country_and_sector(self):
        if "ISSUER" not in self.df.columns:
            print("ISSUER column is missing. Cannot count unique issuers.")
            return

        if "ISIN" not in self.df.columns:
            print("ISIN column is missing. Cannot count unique issues.")
            return

        if self.sector_col not in self.df.columns:
            print(f"{self.sector_col} column is missing. Cannot split by sector.")
            return

        country_col = self._analysis_country_col()
        country_label = self._analysis_country_label()

        self._require_columns([country_col, self.sector_col, "ISSUER", "ISIN"])

        plot_df = self.df.dropna(subset=[country_col]).copy()

        if plot_df.empty:
            print("No country data available.")
            return

        plot_df[country_col] = self._safe_category(plot_df, country_col)
        plot_df[self.sector_col] = self._safe_category(plot_df, self.sector_col)
        plot_df["ISSUER"] = self._safe_category(plot_df, "ISSUER")
        plot_df["ISIN"] = self._safe_category(plot_df, "ISIN")

        grouped = (
            plot_df
            .groupby([country_col, self.sector_col], dropna=False)
            .agg(
                Unique_Issuers=("ISSUER", "nunique"),
                Unique_Issues=("ISIN", "nunique"),
            )
            .reset_index()
        )

        if grouped.empty:
            print("No grouped issuer/issue data available.")
            return

        country_order = (
            grouped
            .groupby(country_col, dropna=False)["Unique_Issuers"]
            .sum()
            .sort_values(ascending=False)
            .index
            .astype(str)
            .tolist()
        )

        sectors = (
            grouped[self.sector_col]
            .dropna()
            .astype(str)
            .drop_duplicates()
            .tolist()
        )

        color_cycle = px.colors.qualitative.Plotly
        sector_color = {
            sector: color_cycle[i % len(color_cycle)]
            for i, sector in enumerate(sectors)
        }

        fig = make_subplots(
            rows=1,
            cols=2,
            shared_xaxes=False,
            subplot_titles=(
                "Unique Issuers per Country & Sector",
                "Unique Issues (ISIN) per Country & Sector",
            ),
            horizontal_spacing=0.08,
        )

        legend_shown = set()

        for sector in sectors:
            sector_df = grouped[grouped[self.sector_col].astype(str) == sector].copy()

            # Reindex only the numeric count columns.
            # Do NOT use fill_value=0 on the full dataframe because it also contains string columns.
            sector_counts = (
                sector_df
                .set_index(country_col)[["Unique_Issuers", "Unique_Issues"]]
                .reindex(country_order)
            )

            sector_counts["Unique_Issuers"] = sector_counts["Unique_Issuers"].fillna(0).astype(int)
            sector_counts["Unique_Issues"] = sector_counts["Unique_Issues"].fillna(0).astype(int)

            sector_counts = sector_counts.reset_index()
            sector_counts[self.sector_col] = sector

            show_legend = sector not in legend_shown
            legend_shown.add(sector)

            fig.add_trace(
                go.Bar(
                    name=sector,
                    x=sector_counts[country_col],
                    y=sector_counts["Unique_Issuers"],
                    marker_color=sector_color[sector],
                    text=sector_counts["Unique_Issuers"].where(
                        sector_counts["Unique_Issuers"] > 0
                    ),
                    textposition="inside",
                    legendgroup=sector,
                    showlegend=show_legend,
                    hovertemplate=(
                        f"<b>{sector}</b><br>"
                        f"{country_label}: %{{x}}<br>"
                        "Unique Issuers: %{y}<extra></extra>"
                    ),
                ),
                row=1,
                col=1,
            )

            fig.add_trace(
                go.Bar(
                    name=sector,
                    x=sector_counts[country_col],
                    y=sector_counts["Unique_Issues"],
                    marker_color=sector_color[sector],
                    text=sector_counts["Unique_Issues"].where(
                        sector_counts["Unique_Issues"] > 0
                    ),
                    textposition="inside",
                    legendgroup=sector,
                    showlegend=False,
                    hovertemplate=(
                        f"<b>{sector}</b><br>"
                        f"{country_label}: %{{x}}<br>"
                        "Unique Issues: %{y}<extra></extra>"
                    ),
                ),
                row=1,
                col=2,
            )

        fig.update_layout(
            barmode="stack",
            title_text=f"Unique Issuers & Unique Issues per Country and Sector{self._title_suffix()}",
            legend_title="Sector",
            template="plotly_white",
            height=700,
            bargap=0.15,
        )

        fig.update_xaxes(
            categoryorder="array",
            categoryarray=country_order,
            tickangle=-45,
            row=1,
            col=1,
        )
        fig.update_xaxes(
            categoryorder="array",
            categoryarray=country_order,
            tickangle=-45,
            row=1,
            col=2,
        )

        fig.update_yaxes(title_text="Unique Issuers", row=1, col=1)
        fig.update_yaxes(title_text="Unique Issues (ISIN)", row=1, col=2)

        fig.show()

    def summary(self):
        country_col = self._analysis_country_col()

        print("\nSummary:")
        print(f"LATAM only: {self.latam_only}")
        print(f"LATAM subregions: {self._latam_scope_text()}")
        print(f"Exclude Government sector: {self.exclude_government}")
        print(f"Total bonds: {len(self.df)}")

        if self.latam_subregion_col in self.df.columns:
            clean_subregions = self.df[self.latam_subregion_col].dropna().astype(str).str.strip()
            if not clean_subregions.empty:
                print(f"\nNumber of LatAm subregions represented: {clean_subregions.nunique()}")
                print("LatAm subregions represented:")
                print(", ".join(sorted(clean_subregions.unique())))

        clean_countries = self.df[country_col].dropna().astype(str).str.strip()
        print(f"\nNumber of countries: {clean_countries.nunique()}")
        print("Countries represented:")
        print(", ".join(sorted(clean_countries.unique())))

        if not self._latam_scope_active() and self.latam_country_col in self.df.columns:
            latam_df = self.df.dropna(subset=[self.latam_country_col]).copy()
            print(f"\nLatin America / Caribbean bonds: {len(latam_df)}")
            if not latam_df.empty:
                print("Latin America / Caribbean countries represented:")
                print(", ".join(sorted(latam_df[self.latam_country_col].dropna().unique())))

        clean_sectors = self.df[self.sector_col].dropna().astype(str).str.strip()
        print(f"\nNumber of sectors: {clean_sectors.nunique()}")
        print("Sectors represented:")
        print(", ".join(sorted(clean_sectors.unique())))

        if "ISIN" in self.df.columns:
            print(f"\nUnique bonds (by ISIN): {self.df['ISIN'].dropna().nunique()}")

        if "PAR_VAL_USD" in self.df.columns:
            print("\nTotal PAR value USD:", round(self.df["PAR_VAL_USD"].sum(), 2))

        if "MV" in self.df.columns:
            print("Total market value:", round(self.df["MV"].sum(), 2))

        print("\nAverage values:")
        for col in ["PRICE", "YTW", "OAD", "WEIGHT", "CPN", "COUPON"]:
            if col in self.df.columns:
                print(f"Average {col}: {round(self.df[col].mean(), 4)}")

        if self.latam_subregion_col in self.df.columns:
            subregion_counts = (
                self.df[self.latam_subregion_col]
                .dropna()
                .astype(str)
                .str.strip()
                .value_counts()
            )
            if not subregion_counts.empty:
                print("\nTop LatAm subregions by number of bonds:")
                print(subregion_counts)

        print("\nTop countries by number of bonds:")
        print(
            self.df[country_col]
            .dropna()
            .astype(str)
            .str.strip()
            .value_counts()
            .head(10)
        )

        if not self._latam_scope_active() and self.latam_country_col in self.df.columns:
            print("\nTop Latin America / Caribbean countries by number of bonds:")
            print(
                self.df[self.latam_country_col]
                .dropna()
                .astype(str)
                .str.strip()
                .value_counts()
                .head(10)
            )

        print("\nTop sectors by number of bonds:")
        print(
            self.df[self.sector_col]
            .dropna()
            .astype(str)
            .str.strip()
            .value_counts()
            .head(10)
        )

        if "PAR_VAL_USD" in self.df.columns:
            print("\nTop sectors by total PAR value USD:")
            print(
                self.df
                .dropna(subset=[self.sector_col])
                .groupby(self.sector_col)["PAR_VAL_USD"]
                .sum()
                .sort_values(ascending=False)
                .head(10)
            )


# ==========================================================
# --- RUN ---
# ==========================================================

if __name__ == "__main__":
    analyzer = BondDatasetAnalyzer(
        file_path=str(BBG_BONDS),
        sheet_name=DEFAULT_SHEET,
        issue_date_cap="2023-12-31",
        latam_only=True,
        latam_subregions=["South America", "Mexico / Central America"],  # examples: "all", ["South America"], ["Caribbean"], ["South America", "Caribbean"]
        exclude_government=True
    )

    analyzer.load_and_clean()

    analyzer.plot_issue_year_repartition(split_by_sector=True, barmode="stack")
    analyzer.plot_maturity_year_repartition(split_by_sector=True, barmode="stack")
    analyzer.plot_country_repartition()
    analyzer.plot_par_value_dashboard()
    analyzer.plot_sector_repartition()
    analyzer.plot_yield_duration_by_sector()
    analyzer.plot_unique_issuers_and_issues_by_country_and_sector()
    analyzer.summary()

# %%
