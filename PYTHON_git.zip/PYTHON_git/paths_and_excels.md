# Data location

All scripts use `C:\Users\Utilisateur\Desktop\THESIS\DATASET`, with `Input` and `Output` subfolders. Change `DATA_DIR` once in `path_config.py` if it moves.
