# %% 

import pandas as pd
import yfinance as yf
from datetime import datetime, timedelta
from path_config import FX_RATES

START_DATE = "2000-01-01"
END_DATE = (datetime.today() + timedelta(days=1)).strftime("%Y-%m-%d")  # yfinance end is exclusive

currencies = [
    "EUR", "AUD", "CAD", "CHF", "USD", "HKD", "CNY", "JPY",
    "NOK", "NZD", "SEK", "GBP", "INR", "IDR", "PLN", "RUB"
]

ticker_map = {
    "EUR": {"ticker": "EURUSD=X", "invert": False},
    "AUD": {"ticker": "AUDUSD=X", "invert": False},
    "CAD": {"ticker": "CADUSD=X", "invert": False},
    "CHF": {"ticker": "CHFUSD=X", "invert": False},
    "USD": {"ticker": None,       "invert": False},
    "HKD": {"ticker": "HKDUSD=X", "invert": False},
    "CNY": {"ticker": "CNYUSD=X", "invert": False},
    "JPY": {"ticker": "JPYUSD=X", "invert": False},
    "NOK": {"ticker": "NOKUSD=X", "invert": False},
    "NZD": {"ticker": "NZDUSD=X", "invert": False},
    "SEK": {"ticker": "SEKUSD=X", "invert": False},
    "GBP": {"ticker": "GBPUSD=X", "invert": False},
    "INR": {"ticker": "INRUSD=X", "invert": False},
    "IDR": {"ticker": "IDRUSD=X", "invert": False},
    "PLN": {"ticker": "PLNUSD=X", "invert": False},
    "RUB": {"ticker": "RUBUSD=X", "invert": False},
}

# Collect Yahoo tickers excluding USD
yahoo_tickers = [v["ticker"] for v in ticker_map.values() if v["ticker"] is not None]

# Download all at once
raw = yf.download(
    tickers=yahoo_tickers,
    start=START_DATE,
    end=END_DATE,
    interval="1d",
    auto_adjust=False,
    progress=False,
    group_by="ticker",
    threads=True
)

def extract_series(raw_df, ticker):
    """
    Returns a pandas Series for the ticker close.
    Handles both MultiIndex and single-index yfinance outputs.
    """
    if raw_df.empty:
        raise ValueError("No data returned by yfinance.")

    if isinstance(raw_df.columns, pd.MultiIndex):
        if ticker not in raw_df.columns.get_level_values(0):
            raise KeyError(f"{ticker} not found in downloaded data.")
        sub = raw_df[ticker]
        if "Adj Close" in sub.columns:
            s = sub["Adj Close"].copy()
        elif "Close" in sub.columns:
            s = sub["Close"].copy()
        else:
            raise KeyError(f"No Close/Adj Close found for {ticker}.")
        return s

    if "Adj Close" in raw_df.columns:
        return raw_df["Adj Close"].copy()
    if "Close" in raw_df.columns:
        return raw_df["Close"].copy()

    raise KeyError(f"No Close/Adj Close found for {ticker}.")

# Build final dataframe: index = date, columns = currencies, values = USD per 1 CCY
fx_usd = pd.DataFrame(index=raw.index)

for ccy in currencies:
    meta = ticker_map[ccy]

    if ccy == "USD":
        fx_usd[ccy] = 1.0
        continue

    ticker = meta["ticker"]
    invert = meta["invert"]

    s = extract_series(raw, ticker)

    if invert:
        s = 1.0 / s

    fx_usd[ccy] = s

# Normalize index
fx_usd.index = pd.to_datetime(fx_usd.index).normalize()
fx_usd = fx_usd.sort_index()

# Reindex to full daily calendar and fill gaps with latest available value
full_calendar = pd.date_range(start=START_DATE, end=datetime.today().strftime("%Y-%m-%d"), freq="D")
fx_usd = fx_usd.reindex(full_calendar).ffill()

# Keep USD exactly at 1.0
fx_usd["USD"] = 1.0

fx_usd.index.name = "Date"

# Save
fx_usd.to_excel(FX_RATES)

print(fx_usd)
print(f"\nSaved to {FX_RATES}")

# %%
