CODES RUNNING FRAMEWORK:

1. Fetch data from Bloomberg 
	-> fetch_bloom_bonds_level_data.py

2. Build main bonds dataset & describe it
	-> des_em_bonds_bench.py

3. Build SQLite database
	-> build_sql_db.py
	-> reader_db_fct.py

4. Compute risk free rate curve from swaps + feature engineering + z_spreads
	-> cpt_rfr_zc_curve_from_swaps.py
	-> cpt_feature_eng.py
	-> cpt_z_spread.py

5. Modelling

	-> model_full.py

	-> model_des_stats.py
	-> model_linReg.py
	-> model_logReg.py
	-> model_rf.py
	-> model_pca.py

